# Magnetic Line-Leveling and De-striping Toolbox

CAGEO-compliant open-source Python implementation for removing striping artifacts and correcting line-leveling errors in magnetic data.

## Input data
Required columns:
- x: easting
- y: northing
- tmi: total magnetic intensity

## Quick test
```bash
python example/quick_test.py
```

## Output
A new column **CORR4** is added to the dataset.

## Dependencies
Python 3.x, NumPy, SciPy, Pandas
